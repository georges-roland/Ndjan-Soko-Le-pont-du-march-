package com.ndjansoko.modules.harvest.controller;

import com.ndjansoko.modules.harvest.dto.HarvestCreateDto;
import com.ndjansoko.modules.harvest.model.Harvest;
import com.ndjansoko.modules.harvest.service.HarvestService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/harvests")
@CrossOrigin(origins = "*") // Permettre l'accès depuis le frontend React local
public class HarvestController {

    private final HarvestService harvestService;

    @Autowired
    public HarvestController(HarvestService harvestService) {
        this.harvestService = harvestService;
    }

    @PostMapping
    public ResponseEntity<Harvest> createHarvest(@Valid @RequestBody HarvestCreateDto dto, 
                                                 @RequestParam(required = false, defaultValue = "1") Long farmerId) {
        Harvest harvest = harvestService.createHarvest(dto, farmerId);
        return new ResponseEntity<>(harvest, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Harvest>> getAllHarvests() {
        return ResponseEntity.ok(harvestService.getAllHarvests());
    }
    
    @GetMapping("/suggest-price")
    public ResponseEntity<Double> getSuggestedPrice(@RequestParam double avgPrice, @RequestParam String quality) {
        double suggested = harvestService.suggestPrice(avgPrice, quality);
        return ResponseEntity.ok(suggested);
    }
}
