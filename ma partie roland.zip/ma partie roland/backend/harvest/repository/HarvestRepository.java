package com.ndjansoko.modules.harvest.repository;

import com.ndjansoko.modules.harvest.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * Repository pour les récoltes.
 * RESPONSABLE : R
 */
@Repository
public interface HarvestRepository extends JpaRepository<Harvest, Long> {

    List<Harvest> findByFarmerIdOrderByCreatedAtDesc(Long farmerId);

    List<Harvest> findByProductTypeAndStatusOrderByCreatedAtDesc(ProductType type, HarvestStatus status);

    // Recherche géolocalisée dans un rayon (en degrés ~ 10km ≈ 0.09°)
    @Query("SELECT h FROM Harvest h WHERE " +
           "h.status = 'PENDING_TRANSPORT' AND " +
           "h.productType = :type AND " +
           "ABS(h.latitude - :lat) < :radius AND " +
           "ABS(h.longitude - :lng) < :radius")
    List<Harvest> findNearbyByProduct(
        @Param("type") ProductType type,
        @Param("lat") Double lat,
        @Param("lng") Double lng,
        @Param("radius") Double radius
    );

    // TODO R : Ajouter filtre par quantité minimale (pour l'interface acheteur)
}
