package com.ndjansoko.modules.harvest.service;

import com.ndjansoko.modules.auth.model.User;
import com.ndjansoko.modules.auth.model.UserRole;
import com.ndjansoko.modules.harvest.dto.HarvestCreateDto;
import com.ndjansoko.modules.harvest.model.Harvest;
import com.ndjansoko.modules.harvest.model.HarvestStatus;
import com.ndjansoko.modules.harvest.model.QualityCategory;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Service
public class HarvestService {

    // Mock Database in memory
    private final List<Harvest> harvestsDb = new ArrayList<>();
    private final AtomicLong idGenerator = new AtomicLong(1);

    public Harvest createHarvest(HarvestCreateDto dto, Long farmerId) {
        // Mocking user retrieval
        User farmer = new User();
        farmer.setId(farmerId != null ? farmerId : 1L);
        farmer.setRole(UserRole.FARMER);
        farmer.setFullName("Agriculteur Test");
        farmer.setPhoneNumber("600000000");

        Harvest harvest = new Harvest();
        harvest.setId(idGenerator.getAndIncrement());
        harvest.setFarmer(farmer);
        harvest.setProductType(dto.getProductType());
        harvest.setQuantityKg(dto.getQuantityKg());
        harvest.setPricePerKgFcfa(dto.getPricePerKgFcfa());
        harvest.setVariety(dto.getVariety());
        harvest.setLatitude(dto.getLatitude());
        harvest.setLongitude(dto.getLongitude());
        harvest.setVillageName(dto.getVillageName());
        harvest.setRegion(dto.getRegion());
        harvest.setHarvestDate(dto.getHarvestDate());
        harvest.setCreatedOffline(dto.getCreatedOffline() != null ? dto.getCreatedOffline() : false);
        harvest.setMaturityPercent(dto.getMaturityPercent());
        
        // Define QualityCategory
        if (dto.getQualityCategory() != null) {
            try {
                harvest.setQualityCategory(QualityCategory.valueOf(dto.getQualityCategory()));
            } catch (IllegalArgumentException e) {
                harvest.setQualityCategory(QualityCategory.CAT_B); // Default
            }
        } else {
            harvest.setQualityCategory(QualityCategory.CAT_B); // Default
        }

        harvest.setStatus(HarvestStatus.PENDING_TRANSPORT);
        harvest.setCreatedAt(LocalDateTime.now());

        harvestsDb.add(harvest);
        return harvest;
    }

    public List<Harvest> getAllHarvests() {
        return new ArrayList<>(harvestsDb);
    }
    
    public List<Harvest> getHarvestsByFarmer(Long farmerId) {
        return harvestsDb.stream()
                .filter(h -> h.getFarmer().getId().equals(farmerId))
                .collect(Collectors.toList());
    }

    public double suggestPrice(double avgPrice, String qualityCategoryStr) {
        QualityCategory category = QualityCategory.CAT_B;
        if (qualityCategoryStr != null) {
            try {
                category = QualityCategory.valueOf(qualityCategoryStr);
            } catch (Exception ignored) {}
        }

        return switch (category) {
            case CAT_A -> avgPrice * 1.15; // Prime qualité
            case CAT_C -> avgPrice * 0.75; // Décote
            case CAT_B -> avgPrice * 1.00; // Standard
            default -> avgPrice;
        };
    }
}
