package com.ndjansoko.modules.harvest.dto;

import com.ndjansoko.modules.harvest.model.ProductType;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

/**
 * DTO pour créer une annonce de récolte.
 * RESPONSABLE : R
 */
public class HarvestCreateDto {

    @NotNull(message = "Le type de produit est obligatoire")
    private ProductType productType;

    @NotNull @Positive(message = "La quantité doit être positive")
    private Double quantityKg;

    @NotNull @Positive(message = "Le prix doit être positif")
    private Double pricePerKgFcfa;

    private String variety;
    private Double latitude;
    private Double longitude;

    @NotBlank(message = "Le nom du village est obligatoire")
    private String villageName;

    private String region;
    private LocalDate harvestDate;
    private Boolean createdOffline = false;

    private String qualityCategory;
    private Double maturityPercent;

    public HarvestCreateDto() {}

    // Getters and Setters
    public ProductType getProductType() { return productType; }
    public void setProductType(ProductType productType) { this.productType = productType; }

    public Double getQuantityKg() { return quantityKg; }
    public void setQuantityKg(Double quantityKg) { this.quantityKg = quantityKg; }

    public Double getPricePerKgFcfa() { return pricePerKgFcfa; }
    public void setPricePerKgFcfa(Double pricePerKgFcfa) { this.pricePerKgFcfa = pricePerKgFcfa; }

    public String getVariety() { return variety; }
    public void setVariety(String variety) { this.variety = variety; }

    public Double getLatitude() { return latitude; }
    public void setLatitude(Double latitude) { this.latitude = latitude; }

    public Double getLongitude() { return longitude; }
    public void setLongitude(Double longitude) { this.longitude = longitude; }

    public String getVillageName() { return villageName; }
    public void setVillageName(String villageName) { this.villageName = villageName; }

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public LocalDate getHarvestDate() { return harvestDate; }
    public void setHarvestDate(LocalDate harvestDate) { this.harvestDate = harvestDate; }

    public Boolean getCreatedOffline() { return createdOffline; }
    public void setCreatedOffline(Boolean createdOffline) { this.createdOffline = createdOffline; }

    public String getQualityCategory() { return qualityCategory; }
    public void setQualityCategory(String qualityCategory) { this.qualityCategory = qualityCategory; }

    public Double getMaturityPercent() { return maturityPercent; }
    public void setMaturityPercent(Double maturityPercent) { this.maturityPercent = maturityPercent; }
}
