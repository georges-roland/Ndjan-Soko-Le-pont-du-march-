package com.ndjansoko.modules.harvest.model;

/**
 * Catégories qualité détectées par l'IA (TFLite).
 * RESPONSABLE : R
 */
public enum QualityCategory {
    CAT_A,  // Parfaite - prix premium
    CAT_B,  // Moyenne - prix standard
    CAT_C   // À consommer rapidement - prix réduit
}
