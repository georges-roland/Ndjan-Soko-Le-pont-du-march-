package com.ndjansoko.modules.harvest.model;

import com.ndjansoko.modules.auth.model.User;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Entité Récolte : annonce publiée par un agriculteur.
 * RESPONSABLE : R
 */
@Entity
@Table(name = "harvests")
public class Harvest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "farmer_id", nullable = false)
    private User farmer;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ProductType productType;

    @Column(nullable = false)
    private Double quantityKg;

    @Column(nullable = false)
    private Double pricePerKgFcfa;

    private String variety;
    private Double latitude;
    private Double longitude;
    private String villageName;
    private String region;

    @Enumerated(EnumType.STRING)
    private QualityCategory qualityCategory;

    private Double maturityPercent;
    private String photoPath;

    @Enumerated(EnumType.STRING)
    private HarvestStatus status = HarvestStatus.PENDING_TRANSPORT;

    private LocalDate harvestDate;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    private Boolean createdOffline = false;

    public Harvest() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getFarmer() { return farmer; }
    public void setFarmer(User farmer) { this.farmer = farmer; }

    public ProductType getProductType() { return productType; }
    public void setProductType(ProductType productType) { this.productType = productType; }

    public Double getQuantityKg() { return quantityKg; }
    public void setQuantityKg(Double quantityKg) { this.quantityKg = quantityKg; }

    public Double getPricePerKgFcfa() { return pricePerKgFcfa; }
    public void setPricePerKgFcfa(Double pricePerKgFcfa) { this.pricePerKgFcfa = pricePerKgFcfa; }

    public String getVariety() { return variety; }
    public void setVariety(String variety) { this.variety = variety; }

    public Double getLatitude() { return latitude; }
    public void setLatitude(Double latitude) { this.latitude = latitude; }

    public Double getLongitude() { return longitude; }
    public void setLongitude(Double longitude) { this.longitude = longitude; }

    public String getVillageName() { return villageName; }
    public void setVillageName(String villageName) { this.villageName = villageName; }

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public QualityCategory getQualityCategory() { return qualityCategory; }
    public void setQualityCategory(QualityCategory qualityCategory) { this.qualityCategory = qualityCategory; }

    public Double getMaturityPercent() { return maturityPercent; }
    public void setMaturityPercent(Double maturityPercent) { this.maturityPercent = maturityPercent; }

    public String getPhotoPath() { return photoPath; }
    public void setPhotoPath(String photoPath) { this.photoPath = photoPath; }

    public HarvestStatus getStatus() { return status; }
    public void setStatus(HarvestStatus status) { this.status = status; }

    public LocalDate getHarvestDate() { return harvestDate; }
    public void setHarvestDate(LocalDate harvestDate) { this.harvestDate = harvestDate; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public Boolean getCreatedOffline() { return createdOffline; }
    public void setCreatedOffline(Boolean createdOffline) { this.createdOffline = createdOffline; }
}
