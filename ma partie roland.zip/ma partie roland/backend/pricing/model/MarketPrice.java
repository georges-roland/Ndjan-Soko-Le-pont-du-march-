package com.ndjansoko.modules.pricing.model;

import com.ndjansoko.modules.harvest.model.ProductType;
import jakarta.persistence.*;
import java.time.LocalDate;

/**
 * Prix de marché journalier par produit.
 * RESPONSABLE : R
 */
@Entity
@Table(name = "market_prices")
public class MarketPrice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ProductType productType;

    @Column(nullable = false)
    private String marketName;

    @Column(nullable = false)
    private Double avgPricePerKgFcfa;

    private Double minPrice;
    private Double maxPrice;

    @Column(nullable = false)
    private LocalDate priceDate;

    public MarketPrice() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public ProductType getProductType() { return productType; }
    public void setProductType(ProductType productType) { this.productType = productType; }

    public String getMarketName() { return marketName; }
    public void setMarketName(String marketName) { this.marketName = marketName; }

    public Double getAvgPricePerKgFcfa() { return avgPricePerKgFcfa; }
    public void setAvgPricePerKgFcfa(Double avgPricePerKgFcfa) { this.avgPricePerKgFcfa = avgPricePerKgFcfa; }

    public Double getMinPrice() { return minPrice; }
    public void setMinPrice(Double minPrice) { this.minPrice = minPrice; }

    public Double getMaxPrice() { return maxPrice; }
    public void setMaxPrice(Double maxPrice) { this.maxPrice = maxPrice; }

    public LocalDate getPriceDate() { return priceDate; }
    public void setPriceDate(LocalDate priceDate) { this.priceDate = priceDate; }
}
