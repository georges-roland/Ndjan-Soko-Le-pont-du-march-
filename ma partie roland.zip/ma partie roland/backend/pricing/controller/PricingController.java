package com.ndjansoko.modules.pricing.controller;

import com.ndjansoko.modules.pricing.model.MarketPrice;
import com.ndjansoko.modules.pricing.service.PricingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/prices")
@CrossOrigin(origins = "*") // Permettre l'accès depuis le frontend React local
public class PricingController {

    private final PricingService pricingService;

    @Autowired
    public PricingController(PricingService pricingService) {
        this.pricingService = pricingService;
    }

    @GetMapping("/today")
    public ResponseEntity<List<MarketPrice>> getTodayPrices() {
        List<MarketPrice> todayPrices = pricingService.getTodayPrices();
        return ResponseEntity.ok(todayPrices);
    }
}
