package com.ndjansoko.modules.pricing.service;

import com.ndjansoko.modules.harvest.model.ProductType;
import com.ndjansoko.modules.pricing.model.MarketPrice;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class PricingService {

    // Mock Database in memory
    private final List<MarketPrice> pricesDb = new ArrayList<>();
    private final AtomicLong idGenerator = new AtomicLong(1);

    @PostConstruct
    public void seedDefaultPrices() {
        if (pricesDb.isEmpty()) {
            MarketPrice tomato = new MarketPrice();
            tomato.setId(idGenerator.getAndIncrement());
            tomato.setProductType(ProductType.TOMATO);
            tomato.setMarketName("Mfoundi");
            tomato.setAvgPricePerKgFcfa(400.0);
            tomato.setMinPrice(350.0);
            tomato.setMaxPrice(500.0);
            tomato.setPriceDate(LocalDate.now());

            MarketPrice corn = new MarketPrice();
            corn.setId(idGenerator.getAndIncrement());
            corn.setProductType(ProductType.OTHER); // Maïs sec (Fallback to OTHER if not in ProductType enum)
            corn.setMarketName("Mokolo");
            corn.setAvgPricePerKgFcfa(250.0);
            corn.setMinPrice(200.0);
            corn.setMaxPrice(300.0);
            corn.setPriceDate(LocalDate.now());

            pricesDb.add(tomato);
            pricesDb.add(corn);
        }
    }

    public List<MarketPrice> getTodayPrices() {
        // Returning seed data representing today's prices
        return new ArrayList<>(pricesDb);
    }
}
