package com.ndjansoko.modules.ussd.service;

import com.ndjansoko.modules.ussd.model.UssdSession;
import com.ndjansoko.modules.ussd.repository.UssdSessionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * Service de génération des menus USSD dynamiques.
 * RESPONSABLE : A
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * "Implémente processUssdRequest() dans ce service Spring Boot.
 * Le paramètre 'input' est la saisie de l'utilisateur (ex: '1', '2', '1*2*50').
 * La logique doit être un switch sur currentStep de la UssdSession :
 * - Si step=START ou session nouvelle : afficher le menu principal
 *   'CON Ndjan-Soko :\n1. Enregistrer une récolte\n2. Prix du marché\n3. Mon solde'
 * - Si step=MAIN_MENU et input='1' : afficher 'CON Choisissez le produit :\n1. Tomate\n2. Manioc\n3. Plantain'
 * - Si step=SELECT_PRODUCT : stocker le produit en session, demander la quantité
 * - Si step=ENTER_QUANTITY : stocker la quantité, demander le prix
 * - Si step=ENTER_PRICE : créer l'annonce Harvest en base et répondre
 *   'END Annonce publiée ! Vos tomates sont visibles sur Ndjan-Soko.'
 * Les réponses commencent par CON (continue) ou END (termine la session).
 * Utilise UssdSession pour mémoriser l'étape courante entre les requêtes."
 */
@Service
@RequiredArgsConstructor
public class UssdService {

    private final UssdSessionRepository sessionRepository;

    /**
     * Point d'entrée unique : traite la requête USSD et retourne la réponse textuelle.
     * TODO A : Implémenter avec l'aide de l'IA.
     * @param sessionId  ID de session de l'opérateur
     * @param phoneNumber Numéro de l'utilisateur
     * @param input       Saisie de l'utilisateur (vide si premier appel)
     * @return texte USSD commençant par CON (continue) ou END (fin)
     */
    public String processUssdRequest(String sessionId, String phoneNumber, String input) {
        throw new UnsupportedOperationException("TODO A : Implémenter processUssdRequest()");
    }

    /**
     * Construit le menu principal USSD.
     * TODO A : Compléter.
     */
    private String buildMainMenu() {
        return "CON Ndjan-Soko :\n" +
               "1. Enregistrer une récolte\n" +
               "2. Prix du marché\n" +
               "3. Mon solde séquestre";
    }
}
