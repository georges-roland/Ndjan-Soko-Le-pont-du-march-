package com.ndjansoko.modules.logistics.controller;

import com.ndjansoko.modules.logistics.service.LogisticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Contrôleur REST pour la logistique.
 * RESPONSABLE : B
 *
 * Endpoints :
 *   POST /api/logistics/group        -> Lance manuellement le groupage
 *   POST /api/trips                  -> Déclarer un trajet (transporteur)
 *   POST /api/logistics/qr/{code}    -> Valider chargement via QR
 *   GET  /api/trips/my               -> Mes trajets (transporteur connecté)
 */
@RestController
@RequestMapping("/api/logistics")
@RequiredArgsConstructor
@CrossOrigin(origins = "${cors.allowed-origins}")
public class LogisticsController {

    private final LogisticsService logisticsService;

    @PostMapping("/group")
    public ResponseEntity<String> runGrouping() {
        logisticsService.runGroupingAlgorithm();
        return ResponseEntity.ok("Algorithme de groupage exécuté");
    }

    @PostMapping("/qr/{qrCode}")
    public ResponseEntity<String> validateLoading(@PathVariable String qrCode) {
        // TODO B : extraire transporterId depuis SecurityContext
        logisticsService.validateLoadingByQrCode(qrCode, 1L);
        return ResponseEntity.ok("Chargement validé");
    }
}
