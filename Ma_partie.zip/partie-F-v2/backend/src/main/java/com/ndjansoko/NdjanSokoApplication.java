package com.ndjansoko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Point d'entrée principal de l'application Ndjan-Soko.
 * "Le Pont du Marché" - Connecter les agriculteurs camerounais aux marchés urbains.
 */
@SpringBootApplication
public class NdjanSokoApplication {
    public static void main(String[] args) {
        SpringApplication.run(NdjanSokoApplication.class, args);
    }
}
