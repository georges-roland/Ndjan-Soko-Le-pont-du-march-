package com.ndjansoko.modules.logistics.model;

import com.ndjansoko.modules.auth.model.User;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

/**
 * Trajet déclaré par un transporteur.
 * RESPONSABLE : B
 */
@Entity
@Table(name = "trips")
@Data
@NoArgsConstructor
public class Trip {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transporter_id", nullable = false)
    private User transporter;

    @Column(nullable = false)
    private String departureCity;

    @Column(nullable = false)
    private String arrivalCity;

    @Column(nullable = false)
    private LocalDateTime departureTime;

    @Column(nullable = false)
    private Double totalCapacityKg;      // Capacité totale du camion

    @Column(nullable = false)
    private Double availableCapacityKg;  // Espace restant disponible

    @Column(nullable = false)
    private Double pricePerKgFcfa;       // Prix de transport demandé

    @Enumerated(EnumType.STRING)
    private TripStatus status = TripStatus.OPEN;

    // Itinéraire optimisé (chemin JSON des arrêts)
    @Column(columnDefinition = "TEXT")
    private String routeJson;            // JSON : liste des arrêts GPS

    private LocalDateTime createdAt = LocalDateTime.now();

    // ====================================================
    // TODO B : Ajouter validation -> availableCapacityKg <= totalCapacityKg
    // ====================================================
}
