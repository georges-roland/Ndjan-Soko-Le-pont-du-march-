package com.ndjansoko.modules.pricing.controller;

import org.springframework.web.bind.annotation.*;

/**
 * Contrôleur REST pour la Bourse des Prix.
 * RESPONSABLE : R
 *
 * Endpoints :
 *   GET /api/prices/today           -> Prix du jour pour tous les produits
 *   GET /api/prices/{product}       -> Historique prix d'un produit
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * "Crée un service PricingService avec une méthode getTodayPrices() qui
 * retourne la liste des MarketPrice du jour, groupés par productType.
 * Ajoute aussi une méthode seedDefaultPrices() annotée @PostConstruct
 * pour insérer des prix fictifs au démarrage si la table est vide,
 * afin de pouvoir tester l'application sans données réelles."
 */
@RestController
@RequestMapping("/api/prices")
@CrossOrigin(origins = "${cors.allowed-origins}")
public class PricingController {

    // TODO R : Injecter PricingService

    @GetMapping("/today")
    public Object getTodayPrices() {
        throw new UnsupportedOperationException("TODO R : Implémenter getTodayPrices()");
    }
}
