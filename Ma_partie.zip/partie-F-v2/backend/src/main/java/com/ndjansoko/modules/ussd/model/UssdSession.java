package com.ndjansoko.modules.ussd.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * Session USSD : suivi de l'état de navigation d'un utilisateur sur téléphone basique.
 * RESPONSABLE : A
 *
 * Une session USSD est stateless côté opérateur télécom mais doit être
 * maintenue en base par notre backend pendant toute la durée de la session.
 */
@Entity
@Table(name = "ussd_sessions")
@Data
public class UssdSession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String sessionId;       // ID fourni par l'opérateur télécom

    @Column(nullable = false)
    private String phoneNumber;     // Numéro de l'utilisateur

    @Column(nullable = false)
    private String currentStep;     // Ex: "MAIN_MENU", "SELECT_PRODUCT", "ENTER_QUANTITY"

    @Column(columnDefinition = "TEXT")
    private String collectedData;   // JSON des données collectées jusqu'ici

    @Column(nullable = false)
    private LocalDateTime lastActivity = LocalDateTime.now();

    // ====================================================
    // TODO A : La session expire après 3 minutes d'inactivité.
    // Ajouter une méthode isExpired() et un @Scheduled pour nettoyer.
    // ====================================================
}
