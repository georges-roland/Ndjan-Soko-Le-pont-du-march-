package com.ndjansoko.modules.pricing.model;

import com.ndjansoko.modules.harvest.model.ProductType;
import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

/**
 * Prix de marché journalier par produit (référence Mfoundi, Mokolo, Sandaga).
 * RESPONSABLE : R
 */
@Entity
@Table(name = "market_prices")
@Data
public class MarketPrice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ProductType productType;

    @Column(nullable = false)
    private String marketName;          // "Mfoundi", "Mokolo", "Sandaga"

    @Column(nullable = false)
    private Double avgPricePerKgFcfa;   // Prix moyen du jour

    private Double minPrice;
    private Double maxPrice;

    @Column(nullable = false)
    private LocalDate priceDate;        // Date du cours

    // ====================================================
    // TODO R : Créer une méthode pour calculer le prix suggéré
    // CAT_A = avgPrice * 1.15 (prime qualité)
    // CAT_B = avgPrice * 1.00
    // CAT_C = avgPrice * 0.75 (décote)
    // ====================================================
}
