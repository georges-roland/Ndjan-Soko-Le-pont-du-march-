package com.ndjansoko.modules.logistics.model;

public enum TripStatus {
    OPEN,       // Accepte encore du fret
    FULL,       // Capacité atteinte
    IN_PROGRESS,// En route
    COMPLETED   // Arrivé à destination
}
