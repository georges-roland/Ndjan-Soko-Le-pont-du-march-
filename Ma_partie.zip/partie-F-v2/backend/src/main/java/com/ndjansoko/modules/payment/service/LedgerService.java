package com.ndjansoko.modules.payment.service;

import com.ndjansoko.modules.payment.model.Transaction;
import com.ndjansoko.modules.payment.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.List;
import java.util.Optional;

/**
 * Service du Registre Financier Immuable anti-fraude.
 * RESPONSABLE : D
 *
 * C'est le MODULE LE PLUS INNOVANT du backend.
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * Demande à l'IA : "Dans ce service Spring Boot, complète computeHash() :
 * elle prend une Transaction, concatène ses champs clés (id, totalAmountFcfa,
 * buyerId, farmerId, status, previousHash, createdAt) en une String, puis
 * retourne le hash SHA-256 de cette String en hexadécimal.
 * Complète attachHash() : elle récupère la dernière transaction en base via
 * findTopByOrderByIdDesc(), prend son currentHash comme previousHash de la
 * nouvelle transaction, calcule le currentHash et sauvegarde.
 * Complète verifyChain() : elle parcourt toutes les transactions dans l'ordre
 * et vérifie que le previousHash de chaque transaction correspond bien au
 * currentHash de la précédente. Si une discordance est trouvée, marquer
 * chainValid=false et lever une SecurityException."
 */
@Service
@RequiredArgsConstructor
public class LedgerService {

    private final TransactionRepository transactionRepository;

    /**
     * Calcule le hash SHA-256 d'une transaction.
     * TODO D : Implémenter avec l'aide de l'IA.
     */
    public String computeHash(Transaction transaction) {
        // Concaténer : id + totalAmount + buyerId + farmerId + status + previousHash + createdAt
        // Appeler sha256(concatenatedString)
        throw new UnsupportedOperationException("TODO D : Implémenter computeHash()");
    }

    /**
     * Méthode utilitaire SHA-256 - DÉJÀ IMPLÉMENTÉE pour t'aider.
     * Tu peux l'utiliser dans computeHash().
     */
    public String sha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 non disponible", e);
        }
    }

    /**
     * Attache le hash à une nouvelle transaction avant sauvegarde.
     * TODO D : Implémenter avec l'aide de l'IA.
     */
    public Transaction attachHash(Transaction transaction) {
        throw new UnsupportedOperationException("TODO D : Implémenter attachHash()");
    }

    /**
     * Vérifie l'intégrité de toute la chaîne de transactions.
     * TODO D : Implémenter avec l'aide de l'IA.
     * @throws SecurityException si une fraude est détectée
     */
    public boolean verifyChain() {
        throw new UnsupportedOperationException("TODO D : Implémenter verifyChain()");
    }
}
