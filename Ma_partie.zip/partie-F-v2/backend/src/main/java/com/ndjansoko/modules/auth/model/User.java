package com.ndjansoko.modules.auth.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Entité Utilisateur principale.
 * RESPONSABLE : F
 * Getters/Setters écrits manuellement (sans Lombok) pour compatibilité maximale.
 */
@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String phoneNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private UserRole role;

    private String fullName;
    private String city;

    @Column(nullable = false, columnDefinition = "DECIMAL(3,2) DEFAULT 5.00")
    private Double trustScore = 5.0;

    private Integer totalRatings = 0;

    @Column(nullable = false, columnDefinition = "BOOLEAN DEFAULT TRUE")
    private Boolean isActive = true;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    private LocalDateTime lastLogin;

    // ── Getters ──────────────────────────────────────────────────────────────

    public Long getId()                  { return id; }
    public String getPhoneNumber()       { return phoneNumber; }
    public UserRole getRole()            { return role; }
    public String getFullName()          { return fullName; }
    public String getCity()              { return city; }
    public Double getTrustScore()        { return trustScore; }
    public Integer getTotalRatings()     { return totalRatings; }
    public Boolean getIsActive()         { return isActive; }
    public LocalDateTime getCreatedAt()  { return createdAt; }
    public LocalDateTime getLastLogin()  { return lastLogin; }

    // ── Setters ──────────────────────────────────────────────────────────────

    public void setId(Long id)                        { this.id = id; }
    public void setPhoneNumber(String phoneNumber)    { this.phoneNumber = phoneNumber; }
    public void setRole(UserRole role)                { this.role = role; }
    public void setFullName(String fullName)          { this.fullName = fullName; }
    public void setCity(String city)                  { this.city = city; }
    public void setTrustScore(Double trustScore)      { this.trustScore = trustScore; }
    public void setTotalRatings(Integer totalRatings) { this.totalRatings = totalRatings; }
    public void setIsActive(Boolean isActive)         { this.isActive = isActive; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }

    // ── Logique métier ────────────────────────────────────────────────────────

    /**
     * Ajoute une évaluation reçue et recalcule la note de confiance.
     * Si la note descend sous 3/5, le compte est suspendu automatiquement.
     */
    public void addRating(int stars) {
        double total = this.trustScore * this.totalRatings + stars;
        this.totalRatings++;
        this.trustScore = total / this.totalRatings;
        if (this.trustScore < 3.0) {
            this.isActive = false;
        }
    }
}
