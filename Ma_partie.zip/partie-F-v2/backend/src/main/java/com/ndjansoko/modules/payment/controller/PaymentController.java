package com.ndjansoko.modules.payment.controller;

import com.ndjansoko.modules.payment.model.Transaction;
import com.ndjansoko.modules.payment.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Contrôleur REST pour les paiements Escrow.
 * RESPONSABLE : D
 *
 * Endpoints :
 *   POST /api/payments/escrow         -> Initier le paiement (acheteur)
 *   POST /api/payments/{id}/confirm   -> Confirmer réception (acheteur)
 *   GET  /api/payments/verify-chain   -> Vérifier l'intégrité du registre (admin)
 *   GET  /api/payments/my             -> Mes transactions
 */
@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
@CrossOrigin(origins = "${cors.allowed-origins}")
public class PaymentController {

    private final PaymentService paymentService;
    private final LedgerService ledgerService;

    @PostMapping("/escrow")
    public ResponseEntity<Transaction> initiateEscrow(
            @RequestParam Long harvestId,
            @RequestParam String provider) {
        // TODO D : extraire buyerId depuis SecurityContext
        return ResponseEntity.ok(paymentService.initiateEscrow(1L, harvestId, provider));
    }

    @PostMapping("/{id}/confirm")
    public ResponseEntity<Transaction> confirmReceipt(@PathVariable Long id) {
        // TODO D : extraire buyerId depuis SecurityContext
        return ResponseEntity.ok(paymentService.releaseEscrow(id, 1L));
    }

    @GetMapping("/verify-chain")
    public ResponseEntity<String> verifyChain() {
        boolean valid = ledgerService.verifyChain();
        return ResponseEntity.ok(valid ? "✅ Chaîne intègre - Aucune fraude détectée" : "🚨 ALERTE FRAUDE : chaîne corrompue !");
    }
}
