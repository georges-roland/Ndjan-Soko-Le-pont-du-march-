package com.ndjansoko.modules.ussd.controller;

import com.ndjansoko.modules.ussd.service.UssdService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

/**
 * Contrôleur REST USSD - Interface pour téléphones basiques.
 * RESPONSABLE : A
 *
 * Endpoint :
 *   POST /api/ussd  -> Reçoit les requêtes USSD de l'opérateur télécom (simulé)
 *
 * La réponse est en texte brut (text/plain), pas en JSON.
 */
@RestController
@RequestMapping("/api/ussd")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class UssdController {

    private final UssdService ussdService;

    @PostMapping(produces = MediaType.TEXT_PLAIN_VALUE)
    public String handleUssd(
            @RequestParam String sessionId,
            @RequestParam String phoneNumber,
            @RequestParam(defaultValue = "") String text) {  // 'text' contient la chaîne de saisies

        return ussdService.processUssdRequest(sessionId, phoneNumber, text);
    }
}
