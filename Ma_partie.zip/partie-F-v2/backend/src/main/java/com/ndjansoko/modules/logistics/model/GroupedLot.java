package com.ndjansoko.modules.logistics.model;

import com.ndjansoko.modules.harvest.model.Harvest;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;
import java.time.LocalDateTime;

/**
 * Lot groupé = fusion de plusieurs petites récoltes d'agriculteurs voisins.
 * Créé automatiquement par l'algorithme de groupage.
 * RESPONSABLE : B
 */
@Entity
@Table(name = "grouped_lots")
@Data
@NoArgsConstructor
public class GroupedLot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToMany
    @JoinTable(name = "lot_harvests",
        joinColumns = @JoinColumn(name = "lot_id"),
        inverseJoinColumns = @JoinColumn(name = "harvest_id"))
    private List<Harvest> harvests;      // Les récoltes groupées

    @ManyToOne
    @JoinColumn(name = "trip_id")
    private Trip assignedTrip;           // Camion assigné (null si pas encore trouvé)

    private Double totalQuantityKg;
    private Double centerLatitude;       // Centre géographique du groupe
    private Double centerLongitude;
    private String region;

    @Enumerated(EnumType.STRING)
    private LotStatus status = LotStatus.PENDING_TRUCK;

    private LocalDateTime createdAt = LocalDateTime.now();
    private String qrCode;               // QR Code unique pour le chargement

    // ====================================================
    // TODO B : Générer le QR Code automatiquement @PrePersist
    // Format : "NDJANSOKO-LOT-{id}-{timestamp}"
    // Utiliser java.util.UUID ou SimpleDateFormat
    // ====================================================
}
