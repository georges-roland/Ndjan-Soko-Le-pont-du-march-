package com.ndjansoko.modules.auth.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Code OTP SMS temporaire — durée de vie 10 minutes, usage unique.
 * RESPONSABLE : F
 */
@Entity
@Table(name = "otp_codes")
public class OtpCode {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String phoneNumber;

    @Column(nullable = false, length = 6)
    private String code;

    @Column(nullable = false)
    private LocalDateTime expiresAt;

    private Boolean used = false;

    // ── Getters ───────────────────────────────────────────────────────────────

    public Long getId()                 { return id; }
    public String getPhoneNumber()      { return phoneNumber; }
    public String getCode()             { return code; }
    public LocalDateTime getExpiresAt() { return expiresAt; }
    public Boolean getUsed()            { return used; }

    // ── Setters ───────────────────────────────────────────────────────────────

    public void setId(Long id)                        { this.id = id; }
    public void setPhoneNumber(String phoneNumber)    { this.phoneNumber = phoneNumber; }
    public void setCode(String code)                  { this.code = code; }
    public void setExpiresAt(LocalDateTime expiresAt) { this.expiresAt = expiresAt; }
    public void setUsed(Boolean used)                 { this.used = used; }

    // ── Logique métier ────────────────────────────────────────────────────────

    /**
     * Retourne true si le code est encore utilisable :
     * non consommé ET non expiré.
     */
    public boolean isValid() {
        return !Boolean.TRUE.equals(used) && LocalDateTime.now().isBefore(expiresAt);
    }
}
