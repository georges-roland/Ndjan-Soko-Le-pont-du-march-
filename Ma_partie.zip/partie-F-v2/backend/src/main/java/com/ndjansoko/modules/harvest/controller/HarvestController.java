package com.ndjansoko.modules.harvest.controller;

import com.ndjansoko.modules.harvest.dto.HarvestCreateDto;
import com.ndjansoko.modules.harvest.model.Harvest;
import com.ndjansoko.modules.harvest.service.HarvestService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Contrôleur REST pour les récoltes.
 * RESPONSABLE : R
 *
 * Endpoints :
 *   POST /api/harvests              -> Créer une annonce (agriculteur)
 *   GET  /api/harvests/my           -> Mes annonces (agriculteur connecté)
 *   GET  /api/harvests              -> Catalogue pour les acheteurs (filtres)
 *   GET  /api/harvests/{id}/suggest-price -> Prix suggéré par l'IA
 */
@RestController
@RequestMapping("/api/harvests")
@RequiredArgsConstructor
@CrossOrigin(origins = "${cors.allowed-origins}")
public class HarvestController {

    private final HarvestService harvestService;

    @PostMapping
    public ResponseEntity<Harvest> createHarvest(@Valid @RequestBody HarvestCreateDto dto) {
        // TODO R : extraire farmerId depuis SecurityContext (utilisateur connecté)
        return ResponseEntity.ok(harvestService.createHarvest(dto, 1L)); // placeholder
    }

    @GetMapping("/my")
    public ResponseEntity<List<Harvest>> getMyHarvests() {
        // TODO R : extraire farmerId depuis SecurityContext
        return ResponseEntity.ok(harvestService.getFarmerHarvests(1L)); // placeholder
    }

    @GetMapping
    public ResponseEntity<List<Harvest>> getAvailableHarvests(
            @RequestParam(required = false) String productType,
            @RequestParam(required = false) String region,
            @RequestParam(required = false) Double minQuantity) {
        return ResponseEntity.ok(harvestService.getAvailableHarvests(productType, region, minQuantity));
    }

    @GetMapping("/{id}/suggest-price")
    public ResponseEntity<Double> suggestPrice(
            @PathVariable Long id,
            @RequestParam String qualityCategory,
            @RequestParam String productType) {
        return ResponseEntity.ok(harvestService.suggestPrice(qualityCategory, productType));
    }
}
