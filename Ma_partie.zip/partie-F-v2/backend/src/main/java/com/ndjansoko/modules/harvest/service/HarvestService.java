package com.ndjansoko.modules.harvest.service;

import com.ndjansoko.modules.harvest.dto.HarvestCreateDto;
import com.ndjansoko.modules.harvest.model.*;
import com.ndjansoko.modules.harvest.repository.HarvestRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Service de gestion des récoltes.
 * RESPONSABLE : R
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * Demande à l'IA : "Dans ce service Spring Boot, complète createHarvest() :
 * récupérer l'utilisateur connecté depuis le SecurityContext, créer l'entité
 * Harvest depuis le DTO HarvestCreateDto, sauvegarder et retourner l'entité.
 * Complète aussi suggestPrice() : prendre la qualityCategory et le productType,
 * calculer un prix suggéré en FCFA en te basant sur le prix moyen du marché
 * stocké dans la table MarketPrice."
 */
@Service
@RequiredArgsConstructor
public class HarvestService {

    private final HarvestRepository harvestRepository;

    /**
     * Crée une nouvelle annonce de récolte.
     * TODO R : Implémenter avec l'aide de l'IA.
     */
    public Harvest createHarvest(HarvestCreateDto dto, Long farmerId) {
        throw new UnsupportedOperationException("TODO R : Implémenter createHarvest()");
    }

    /**
     * Récupère toutes les annonces d'un agriculteur.
     * TODO R : Implémenter.
     */
    public List<Harvest> getFarmerHarvests(Long farmerId) {
        throw new UnsupportedOperationException("TODO R : Implémenter getFarmerHarvests()");
    }

    /**
     * Suggère un prix optimal basé sur la qualité IA et le cours du marché.
     * TODO R : Implémenter avec l'aide de l'IA.
     */
    public Double suggestPrice(String qualityCategory, String productType) {
        throw new UnsupportedOperationException("TODO R : Implémenter suggestPrice()");
    }

    /**
     * Récupère toutes les annonces disponibles (filtrées pour les acheteurs).
     * TODO R : Implémenter avec filtres type/région/quantité min.
     */
    public List<Harvest> getAvailableHarvests(String productType, String region, Double minQuantity) {
        throw new UnsupportedOperationException("TODO R : Implémenter getAvailableHarvests()");
    }
}
