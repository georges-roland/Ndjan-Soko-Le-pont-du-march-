package com.ndjansoko.modules.auth.repository;

import com.ndjansoko.modules.auth.model.OtpCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Repository pour les codes OTP.
 * RESPONSABLE : F
 */
@Repository
public interface OtpRepository extends JpaRepository<OtpCode, Long> {
    Optional<OtpCode> findTopByPhoneNumberAndUsedFalseOrderByIdDesc(String phoneNumber);
}
