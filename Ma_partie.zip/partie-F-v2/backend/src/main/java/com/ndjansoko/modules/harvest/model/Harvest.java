package com.ndjansoko.modules.harvest.model;

import com.ndjansoko.modules.auth.model.User;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Entité Récolte : annonce publiée par un agriculteur.
 * RESPONSABLE : R
 */
@Entity
@Table(name = "harvests")
@Data
@NoArgsConstructor
public class Harvest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "farmer_id", nullable = false)
    private User farmer;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ProductType productType;     // TOMATO, CASSAVA, PLANTAIN, MACABO, AVOCADO...

    @Column(nullable = false)
    private Double quantityKg;           // Quantité en kilogrammes

    @Column(nullable = false)
    private Double pricePerKgFcfa;       // Prix demandé par l'agriculteur (FCFA/kg)

    private String variety;              // Variété (ex: "Roma", "Cherry")

    // Localisation
    private Double latitude;
    private Double longitude;
    private String villageName;          // Nom du village le plus proche
    private String region;               // Moungo, Ouest, Centre...

    // Qualité IA
    @Enumerated(EnumType.STRING)
    private QualityCategory qualityCategory; // CAT_A, CAT_B, CAT_C

    private Double maturityPercent;      // % de maturité détecté par l'IA

    // Photos (chemin de fichier sur le serveur)
    private String photoPath;

    // Statut logistique
    @Enumerated(EnumType.STRING)
    private HarvestStatus status = HarvestStatus.PENDING_TRANSPORT;

    private LocalDate harvestDate;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    // Annonce créée hors-ligne ?
    private Boolean createdOffline = false;

    // ====================================================
    // TODO R : Vérifier que quantityKg > 0 et pricePerKgFcfa > 0
    // via @PrePersist ou dans le service
    // ====================================================
}
