package com.ndjansoko.modules.payment.model;

import com.ndjansoko.modules.auth.model.User;
import com.ndjansoko.modules.harvest.model.Harvest;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

/**
 * Transaction financière avec chaîne de hachage SHA-256 anti-fraude.
 * RESPONSABLE : D
 *
 * PRINCIPE DU REGISTRE IMMUABLE :
 * Chaque transaction contient le hash SHA-256 de la transaction précédente.
 * Si une valeur est modifiée frauduleusement en base, le hash ne correspond
 * plus → alerte de sécurité levée → système verrouillé.
 *
 * Analogie : comme une blockchain, mais simplifiée.
 */
@Entity
@Table(name = "transactions")
@Data
@NoArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "buyer_id", nullable = false)
    private User buyer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "farmer_id", nullable = false)
    private User farmer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transporter_id")
    private User transporter;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "harvest_id", nullable = false)
    private Harvest harvest;

    // Montants en FCFA
    @Column(nullable = false)
    private Double totalAmountFcfa;          // Total payé par l'acheteur

    private Double farmerShareFcfa;          // Part de l'agriculteur
    private Double transporterShareFcfa;     // Part du transporteur
    private Double platformCommissionFcfa;   // 4% pour Ndjan-Soko

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TransactionStatus status = TransactionStatus.PENDING;

    // Mobile Money
    private String mobileMoneyProvider;      // "MTN_MOMO" ou "ORANGE_MONEY"
    private String externalTransactionId;    // Référence chez Campay/Monetbil

    // ===== SÉCURITÉ SHA-256 =====
    @Column(length = 64)
    private String previousHash;             // Hash SHA-256 de la transaction (id-1)

    @Column(length = 64)
    private String currentHash;              // Hash SHA-256 de CETTE transaction

    private Boolean chainValid = true;       // false = alerte fraude détectée !

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    private LocalDateTime confirmedAt;
    private LocalDateTime releasedAt;

    // ====================================================
    // TODO D : Voir LedgerService pour l'implémentation du hachage
    // ====================================================
}
