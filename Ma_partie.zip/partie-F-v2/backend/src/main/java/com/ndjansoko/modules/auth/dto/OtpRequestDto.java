package com.ndjansoko.modules.auth.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

/**
 * DTO pour la demande d'OTP. RESPONSABLE : F
 */
public class OtpRequestDto {

    @NotBlank(message = "Le numéro de téléphone est obligatoire")
    @Pattern(regexp = "^(237)?[67][0-9]{8}$", message = "Numéro camerounais invalide")
    private String phoneNumber;

    public String getPhoneNumber()              { return phoneNumber; }
    public void setPhoneNumber(String p)        { this.phoneNumber = p; }
}
