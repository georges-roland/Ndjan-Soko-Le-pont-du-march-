package com.ndjansoko.modules.payment.service;

import com.ndjansoko.modules.payment.model.*;
import com.ndjansoko.modules.payment.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * Service de gestion du séquestre (Escrow) et des paiements Mobile Money.
 * RESPONSABLE : D
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * "Implémente initiateEscrow() : créer une Transaction avec status=PENDING,
 * calculer farmerShare = totalAmount * 0.96 * 0.80 (80% au fermier),
 * transporterShare = totalAmount * 0.96 * 0.20 (20% au transporteur),
 * platformCommission = totalAmount * 0.04,
 * appeler ledgerService.attachHash() avant de sauvegarder.
 * Implémente releaseEscrow() : changer status=RELEASED, enregistrer releasedAt,
 * simuler les virements (System.out.println) et mettre à jour le hash."
 */
@Service
@RequiredArgsConstructor
public class PaymentService {

    private final TransactionRepository transactionRepository;
    private final LedgerService ledgerService;

    /**
     * Initie le paiement et bloque l'argent dans le séquestre.
     * TODO D : Implémenter avec l'aide de l'IA.
     */
    public Transaction initiateEscrow(Long buyerId, Long harvestId, String mobileMoneyProvider) {
        throw new UnsupportedOperationException("TODO D : Implémenter initiateEscrow()");
    }

    /**
     * Acheteur confirme la réception → libère l'argent.
     * TODO D : Implémenter avec l'aide de l'IA.
     */
    public Transaction releaseEscrow(Long transactionId, Long buyerId) {
        throw new UnsupportedOperationException("TODO D : Implémenter releaseEscrow()");
    }

    /**
     * Simule le paiement Mobile Money (MTN MoMo / Orange Money).
     * En production : appeler l'API Campay.
     * TODO D : Implémenter une simulation (retourner un ID fictif).
     */
    public String simulateMobileMoneyPayment(String phone, Double amount, String provider) {
        // Simuler : retourner "SIM-" + UUID
        return "SIM-" + java.util.UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
}
