package com.ndjansoko.modules.harvest.dto;

import com.ndjansoko.modules.harvest.model.ProductType;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

/**
 * DTO pour créer une annonce de récolte.
 * RESPONSABLE : R
 */
@Data
public class HarvestCreateDto {

    @NotNull(message = "Le type de produit est obligatoire")
    private ProductType productType;

    @NotNull @Positive(message = "La quantité doit être positive")
    private Double quantityKg;

    @NotNull @Positive(message = "Le prix doit être positif")
    private Double pricePerKgFcfa;

    private String variety;
    private Double latitude;
    private Double longitude;

    @NotBlank(message = "Le nom du village est obligatoire")
    private String villageName;

    private String region;
    private LocalDate harvestDate;
    private Boolean createdOffline = false;

    // Résultats IA (envoyés depuis le mobile après analyse TFLite)
    private String qualityCategory; // "CAT_A", "CAT_B", "CAT_C"
    private Double maturityPercent;
}
