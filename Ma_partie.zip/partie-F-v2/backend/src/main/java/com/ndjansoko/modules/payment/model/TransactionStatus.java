package com.ndjansoko.modules.payment.model;

/**
 * États du cycle de vie d'une transaction Escrow.
 * RESPONSABLE : D
 */
public enum TransactionStatus {
    PENDING,     // Paiement initié, en attente de confirmation Mobile Money
    ESCROWED,    // Argent gelé dans le séquestre Ndjan-Soko
    CONFIRMED,   // Acheteur a confirmé la réception
    RELEASED,    // Argent distribué (agriculteur + transporteur + commission)
    DISPUTED,    // Litige ouvert
    REFUNDED     // Remboursé à l'acheteur
}
