package com.ndjansoko.modules.auth.controller;

import com.ndjansoko.modules.auth.dto.*;
import com.ndjansoko.modules.auth.model.User;
import com.ndjansoko.modules.auth.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

/**
 * Contrôleur Auth. RESPONSABLE : F
 *
 *  POST /api/auth/send-otp   → envoie OTP (public)
 *  POST /api/auth/verify-otp → vérifie OTP, retourne JWT (public)
 *  GET  /api/auth/me         → profil utilisateur connecté (JWT requis)
 */
@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/send-otp")
    public ResponseEntity<String> sendOtp(@Valid @RequestBody OtpRequestDto dto) {
        return ResponseEntity.ok(authService.sendOtp(dto));
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<String> verifyOtp(@Valid @RequestBody OtpVerifyDto dto) {
        return ResponseEntity.ok(authService.verifyOtp(dto));
    }

    @GetMapping("/me")
    public ResponseEntity<User> getProfile(@AuthenticationPrincipal User user) {
        return ResponseEntity.ok(user);
    }
}
