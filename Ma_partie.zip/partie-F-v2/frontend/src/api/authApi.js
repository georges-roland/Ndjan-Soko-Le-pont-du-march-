/** Appels API authentification. RESPONSABLE : F */
import apiClient from './apiClient';
export const sendOtp = (phoneNumber) => apiClient.post('/auth/send-otp', { phoneNumber });
export const verifyOtp = (phoneNumber, code, role) => apiClient.post('/auth/verify-otp', { phoneNumber, code, role });
