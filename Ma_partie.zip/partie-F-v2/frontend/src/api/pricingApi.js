/** Appels API prix marché. RESPONSABLE : R */
import apiClient from './apiClient';
export const getTodayPrices = () => apiClient.get('/prices/today');
