/**
 * Context d'authentification global. RESPONSABLE : F
 * COMMENT UTILISER :
 *   import { useAuth } from '../context/AuthContext';
 *   const { user, role, login, logout } = useAuth();
 */
import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext(null);

const decodeJwt = (token) => {
  try {
    return JSON.parse(atob(token.split('.')[1]));
  } catch { return null; }
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [role, setRole] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('ndjan_token');
    if (token) {
      const decoded = decodeJwt(token);
      if (decoded) { setUser(decoded); setRole(decoded.role); }
      else localStorage.removeItem('ndjan_token');
    }
    setLoading(false);
  }, []);

  const login = (token) => {
    localStorage.setItem('ndjan_token', token);
    const decoded = decodeJwt(token);
    setUser(decoded);
    setRole(decoded?.role);
  };

  const logout = () => {
    localStorage.removeItem('ndjan_token');
    setUser(null); setRole(null);
  };

  return (
    <AuthContext.Provider value={{ user, role, loading, login, logout }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
