/**
 * Tableau de bord Acheteur.
 * RESPONSABLE : R (côté bourse des prix) + D (côté paiement)
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * "Tableau de bord acheteur avec : un widget 'Bourse des prix du jour'
 * (appeler getTodayPrices(), afficher sous forme de tableau produit/prix/tendance),
 * un bouton 'Parcourir le catalogue', et un historique des dernières transactions."
 */
import React from 'react';
import { useNavigate } from 'react-router-dom';
const BuyerDashboard = () => {
  const navigate = useNavigate();
  return (
    <div style={{ padding: 20 }}>
      <h2>🛒 Tableau de bord Acheteur</h2>
      <button onClick={() => navigate('/buyer/prices')}>📊 Prix du marché</button>
      <button onClick={() => navigate('/buyer/catalog')} style={{ marginLeft: 10 }}>🔍 Catalogue</button>
      {/* TODO R : Widget prix du jour */}
    </div>
  );
};
export default BuyerDashboard;
