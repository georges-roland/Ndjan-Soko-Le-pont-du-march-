/**
 * Page de paiement sécurisé (Escrow).
 * RESPONSABLE : D
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * "Crée un composant React de paiement Escrow en 3 étapes visuelles :
 * Étape 1 'Résumé' : afficher le récapitulatif de la commande (produit, quantité,
 *   prix marchandise + coût transport = total), et deux boutons de paiement :
 *   'Payer avec MTN MoMo' et 'Payer avec Orange Money'.
 * Étape 2 'Sécurisé' : afficher une animation de cadenas et le message
 *   'Vos fonds sont sécurisés par Ndjan-Soko. Vous pouvez confirmer la livraison
 *   après réception de votre commande.'
 * Étape 3 'Confirmation' : un bouton 'J'ai reçu ma commande ✓' qui appelle
 *   confirmReceipt(transactionId) et affiche 'Merci ! Les fonds ont été libérés.'"
 */
import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { initiateEscrow, confirmReceipt } from '../../api/paymentApi';
const PaymentEscrowPage = () => {
  const { harvestId } = useParams();
  const [step, setStep] = useState(1);
  const [txId, setTxId] = useState(null);
  return (
    <div style={{ padding: 20 }}>
      <h2>🔐 Paiement Sécurisé - Étape {step}/3</h2>
      {/* TODO D : 3 étapes visuelles avec l'aide de l'IA */}
      <p>🚧 TODO D : Implémenter le tunnel de paiement Escrow</p>
    </div>
  );
};
export default PaymentEscrowPage;
