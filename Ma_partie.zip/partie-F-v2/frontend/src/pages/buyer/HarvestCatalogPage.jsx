/**
 * Catalogue des récoltes disponibles (vue acheteur).
 * RESPONSABLE : R
 */
import React, { useState, useEffect } from 'react';
import { getAvailableHarvests } from '../../api/harvestApi';
import { useNavigate } from 'react-router-dom';
const HarvestCatalogPage = () => {
  const [harvests, setHarvests] = useState([]);
  const navigate = useNavigate();
  useEffect(() => { getAvailableHarvests({}).then(r => setHarvests(r.data)); }, []);
  return (
    <div style={{ padding: 20 }}>
      <h2>🔍 Catalogue des récoltes</h2>
      {/* TODO R : Filtres + liste de cartes avec bouton Acheter */}
      {harvests.map(h => (
        <div key={h.id} style={{ border: '1px solid #ddd', padding: 15, marginBottom: 10, borderRadius: 8 }}>
          <strong>{h.productType}</strong> - {h.quantityKg}kg à {h.pricePerKgFcfa} FCFA/kg
          <button onClick={() => navigate(`/buyer/payment/${h.id}`)} style={{ float: 'right' }}>
            Acheter
          </button>
        </div>
      ))}
    </div>
  );
};
export default HarvestCatalogPage;
