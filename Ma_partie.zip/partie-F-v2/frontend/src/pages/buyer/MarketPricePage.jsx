/**
 * Bourse des prix en temps réel.
 * RESPONSABLE : R
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * "Crée un composant React qui affiche les prix du marché du jour.
 * Appeller getTodayPrices() au chargement. Afficher les résultats dans un
 * tableau avec les colonnes : Produit (avec emoji), Prix min (FCFA/kg),
 * Prix moyen, Prix max, Marché de référence.
 * Ajouter une légende de couleur : vert si prix hausse, rouge si baisse
 * (comparer avec les données de la veille si disponibles)."
 */
import React, { useState, useEffect } from 'react';
import { getTodayPrices } from '../../api/pricingApi';
const MarketPricePage = () => {
  const [prices, setPrices] = useState([]);
  useEffect(() => { getTodayPrices().then(r => setPrices(r.data)); }, []);
  return (
    <div style={{ padding: 20 }}>
      <h2>📊 Bourse des Prix - Aujourd'hui</h2>
      {/* TODO R : Tableau de prix avec couleurs */}
      <p>🚧 TODO R : Afficher les prix ici</p>
    </div>
  );
};
export default MarketPricePage;
