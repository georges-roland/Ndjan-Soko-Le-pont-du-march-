/**
 * Tableau de bord Transporteur.
 * RESPONSABLE : B
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * "Tableau de bord transporteur avec : une carte résumant son trajet actif
 * (si existant), un bouton 'Déclarer un nouveau trajet', une liste des
 * lots de groupage disponibles sur sa route, et un bouton 'Scanner QR Code'
 * (utiliser une bibliothèque de scan QR ou simuler avec un champ input)."
 */
import React from 'react';
import { useNavigate } from 'react-router-dom';
const TransporterDashboard = () => {
  const navigate = useNavigate();
  return (
    <div style={{ padding: 20 }}>
      <h2>🚚 Tableau de bord Transporteur</h2>
      <button onClick={() => navigate('/transporter/declare-trip')}>
        ➕ Déclarer un trajet
      </button>
      {/* TODO B : Liste des lots disponibles + bouton scan QR */}
    </div>
  );
};
export default TransporterDashboard;
