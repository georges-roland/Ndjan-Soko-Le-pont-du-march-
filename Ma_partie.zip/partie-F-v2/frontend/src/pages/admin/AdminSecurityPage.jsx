/**
 * Panneau d'administration - Sécurité & Simulateur USSD.
 * RESPONSABLE : A
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * "Crée une page admin avec deux sections :
 * Section 1 'Registre SHA-256' : un bouton 'Vérifier l'intégrité' qui appelle
 *   verifyChain(). Afficher le résultat avec une icône verte (✅ Intègre) ou
 *   rouge (🚨 Fraude détectée !). Ajouter la liste des transactions corrompues.
 * Section 2 'Simulateur USSD' : reproduire visuellement un écran de téléphone
 *   Nokia. Un input pour entrer un numéro de téléphone simulé, et un écran
 *   noir avec du texte vert montrant les menus USSD. Des boutons 0-9 + * + #
 *   pour naviguer. Chaque clic de bouton envoie une requête POST à /api/ussd
 *   et affiche la réponse texte dans l'écran simulé."
 */
import React, { useState } from 'react';
import { verifyChain } from '../../api/paymentApi';
const AdminSecurityPage = () => {
  const [chainStatus, setChainStatus] = useState(null);
  const [ussdScreen, setUssdScreen] = useState('Appuyez sur * pour commencer');
  const [sessionId] = useState('SIM-' + Date.now());

  const handleVerify = async () => {
    const r = await verifyChain();
    setChainStatus(r.data);
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>🛡️ Panneau d'Administration</h2>

      <section style={{ marginBottom: 40 }}>
        <h3>🔗 Registre SHA-256</h3>
        <button onClick={handleVerify} style={{ padding: '10px 20px' }}>
          Vérifier l'intégrité de la chaîne
        </button>
        {chainStatus && <p style={{ marginTop: 10, fontSize: 18 }}>{chainStatus}</p>}
      </section>

      <section>
        <h3>📱 Simulateur USSD</h3>
        {/* TODO A : Implémentation complète du simulateur Nokia avec l'aide de l'IA */}
        <div style={{
          background: '#1a1a1a', color: '#00ff00', padding: 20,
          fontFamily: 'monospace', fontSize: 14, borderRadius: 8,
          minHeight: 150, maxWidth: 280
        }}>
          {ussdScreen}
        </div>
        <p>🚧 TODO A : Ajouter les boutons du clavier Nokia et la logique de navigation</p>
      </section>
    </div>
  );
};
export default AdminSecurityPage;
