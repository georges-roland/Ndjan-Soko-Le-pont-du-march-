/**
 * Page de connexion OTP SMS — Ndjan-Soko.
 * RESPONSABLE : F
 */
import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { sendOtp, verifyOtp } from '../../api/authApi';
import { useAuth } from '../../context/AuthContext';

// ─── Styles en ligne ─────────────────────────────────────────────────────────
const S = {
  page: {
    minHeight: '100vh', display: 'flex', alignItems: 'center',
    justifyContent: 'center', background: 'linear-gradient(135deg, #1B7A3E 0%, #145C2E 100%)',
    fontFamily: 'Arial, sans-serif',
  },
  card: {
    background: '#fff', borderRadius: 20, padding: '40px 36px',
    maxWidth: 400, width: '100%', boxShadow: '0 20px 60px rgba(0,0,0,0.25)',
  },
  logo: { fontSize: 48, textAlign: 'center', marginBottom: 4 },
  title: { textAlign: 'center', color: '#1B7A3E', fontSize: 26, fontWeight: 'bold', margin: '0 0 4px' },
  subtitle: { textAlign: 'center', color: '#888', fontSize: 14, margin: '0 0 28px' },
  label: { display: 'block', color: '#333', fontWeight: 'bold', fontSize: 14, marginBottom: 6 },
  input: {
    width: '100%', padding: '13px 16px', fontSize: 18, border: '2px solid #e0e0e0',
    borderRadius: 12, outline: 'none', boxSizing: 'border-box', transition: 'border .2s',
  },
  hint: { color: '#aaa', fontSize: 12, marginTop: 6 },
  btn: {
    width: '100%', padding: 14, marginTop: 20, background: '#1B7A3E',
    color: '#fff', border: 'none', borderRadius: 12, fontSize: 16,
    fontWeight: 'bold', cursor: 'pointer', transition: 'opacity .2s',
  },
  btnDisabled: { opacity: 0.55, cursor: 'not-allowed' },
  error: {
    background: '#FFEBEE', color: '#B71C1C', padding: '10px 14px',
    borderRadius: 10, fontSize: 13, marginTop: 14,
  },
  success: {
    background: '#E8F5E9', color: '#1B7A3E', padding: '10px 14px',
    borderRadius: 10, fontSize: 13, marginTop: 14,
  },
  back: {
    background: 'none', border: 'none', color: '#1B7A3E', cursor: 'pointer',
    fontSize: 13, marginTop: 12, display: 'block', textAlign: 'center',
  },
  // ── OTP boxes ──
  otpRow: { display: 'flex', gap: 10, justifyContent: 'center', margin: '16px 0' },
  otpBox: {
    width: 48, height: 58, textAlign: 'center', fontSize: 24, fontWeight: 'bold',
    border: '2px solid #e0e0e0', borderRadius: 12, outline: 'none',
    color: '#1B7A3E', transition: 'border .2s',
  },
};

// ─── Composant principal ──────────────────────────────────────────────────────
const LoginPage = () => {
  const [step, setStep]         = useState(1);       // 1 = saisie tel, 2 = saisie OTP
  const [phone, setPhone]       = useState('');
  const [otp, setOtp]           = useState(Array(6).fill(''));
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState('');
  const [info, setInfo]         = useState('');
  const inputRefs               = useRef([]);

  const { login } = useAuth();
  const navigate  = useNavigate();

  // ─── Étape 1 : demande de l'OTP ────────────────────────────────────────────
  const handleSendOtp = async () => {
    setError(''); setInfo('');
    const cleaned = phone.replace(/\s/g, '');
    if (!/^(237)?[67][0-9]{8}$/.test(cleaned)) {
      setError('Numéro invalide. Format attendu : 6XXXXXXXX (MTN ou Orange)');
      return;
    }
    setLoading(true);
    try {
      await sendOtp(cleaned);
      setInfo('Code envoyé ! Vérifiez vos SMS (ou les logs serveur en dev).');
      setStep(2);
    } catch (e) {
      setError(e.response?.data || 'Erreur réseau. Réessayez.');
    } finally {
      setLoading(false);
    }
  };

  // ─── Étape 2 : saisie OTP case par case ────────────────────────────────────
  const handleOtpChange = (index, value) => {
    // N'accepter qu'un chiffre par case
    const digit = value.replace(/\D/g, '').slice(-1);
    const newOtp = [...otp];
    newOtp[index] = digit;
    setOtp(newOtp);
    // Avancer automatiquement à la case suivante
    if (digit && index < 5) inputRefs.current[index + 1]?.focus();
    // Déclencher la vérification si toutes les cases sont remplies
    if (newOtp.every(d => d !== '') && digit) {
      handleVerifyOtp(newOtp.join(''));
    }
  };

  const handleOtpKeyDown = (index, e) => {
    // Retour arrière : vider la case et revenir à la précédente
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  // ─── Étape 2 : vérification de l'OTP ───────────────────────────────────────
  const handleVerifyOtp = async (code) => {
    setError(''); setLoading(true);
    try {
      // role null → verifyOtp ne créera pas de nouvel utilisateur si déjà existant
      const { data: token } = await verifyOtp(phone.replace(/\s/g, ''), code, null);
      login(token);         // stocke le JWT dans localStorage + met à jour le contexte
      navigate('/');        // App.jsx redirige vers le bon dashboard selon le rôle
    } catch (e) {
      const msg = e.response?.data || 'Code incorrect ou expiré.';
      setError(msg);
      setOtp(Array(6).fill(''));
      setTimeout(() => inputRefs.current[0]?.focus(), 100);
    } finally {
      setLoading(false);
    }
  };

  // ─── Rendu ──────────────────────────────────────────────────────────────────
  return (
    <div style={S.page}>
      <div style={S.card}>
        <div style={S.logo}>🌿</div>
        <h1 style={S.title}>Ndjan-Soko</h1>
        <p style={S.subtitle}>Le Pont du Marché</p>

        {error   && <div style={S.error}>⚠️ {error}</div>}
        {info    && <div style={S.success}>✅ {info}</div>}

        {/* ── Étape 1 : numéro de téléphone ── */}
        {step === 1 && (
          <>
            <label style={S.label}>Votre numéro MTN ou Orange</label>
            <input
              style={S.input}
              type="tel"
              placeholder="670 000 000"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSendOtp()}
              autoFocus
            />
            <span style={S.hint}>Exemple : 670 000 000 ou 690 000 000</span>

            <button
              style={{ ...S.btn, ...(loading ? S.btnDisabled : {}) }}
              onClick={handleSendOtp}
              disabled={loading}
            >
              {loading ? 'Envoi en cours...' : '📲 Recevoir le code SMS'}
            </button>

            <button style={S.back} onClick={() => navigate('/register')}>
              Première connexion ? Choisir mon rôle →
            </button>
          </>
        )}

        {/* ── Étape 2 : saisie du code OTP ── */}
        {step === 2 && (
          <>
            <label style={{ ...S.label, textAlign: 'center' }}>
              Entrez le code reçu par SMS
            </label>
            <div style={S.otpRow}>
              {otp.map((digit, i) => (
                <input
                  key={i}
                  ref={el => (inputRefs.current[i] = el)}
                  style={{
                    ...S.otpBox,
                    borderColor: digit ? '#1B7A3E' : '#e0e0e0',
                    background: digit ? '#E8F5E9' : '#fff',
                  }}
                  type="text"
                  inputMode="numeric"
                  maxLength={2}
                  value={digit}
                  onChange={e => handleOtpChange(i, e.target.value)}
                  onKeyDown={e => handleOtpKeyDown(i, e)}
                  autoFocus={i === 0}
                />
              ))}
            </div>

            {loading && (
              <p style={{ textAlign: 'center', color: '#1B7A3E' }}>Vérification...</p>
            )}

            <button style={S.back} onClick={() => { setStep(1); setOtp(Array(6).fill('')); setError(''); }}>
              ← Changer de numéro
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default LoginPage;
