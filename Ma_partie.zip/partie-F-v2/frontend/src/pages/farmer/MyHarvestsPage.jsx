/**
 * Liste des récoltes de l'agriculteur connecté.
 * RESPONSABLE : R
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * "Crée un composant React qui appelle getMyHarvests() au chargement (useEffect),
 * affiche un spinner pendant le chargement, puis une liste de cartes.
 * Chaque carte montre : le type de produit avec un emoji, la quantité en kg,
 * le prix FCFA/kg, et un badge de statut coloré (PENDING=orange, GROUPED=bleu,
 * IN_TRANSIT=vert, DELIVERED=gris)."
 */
import React, { useState, useEffect } from 'react';
import { getMyHarvests } from '../../api/harvestApi';

const MyHarvestsPage = () => {
  const [harvests, setHarvests] = useState([]);
  useEffect(() => { getMyHarvests().then(r => setHarvests(r.data)); }, []);
  return (
    <div style={{ padding: 20 }}>
      <h2>📦 Mes annonces</h2>
      {/* TODO R : Afficher la liste avec des cartes stylées */}
      {harvests.map(h => <p key={h.id}>{h.productType} - {h.quantityKg}kg</p>)}
    </div>
  );
};
export default MyHarvestsPage;
