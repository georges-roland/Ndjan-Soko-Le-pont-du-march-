/**
 * Tableau de bord Agriculteur.
 * RESPONSABLE : R
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * "Crée un tableau de bord React pour un agriculteur avec :
 * - En haut : son nom et sa note de confiance (étoiles)
 * - 3 tuiles principales : 'Publier une récolte' (→ /farmer/create),
 *   'Mes annonces' (→ /farmer/my-harvests), 'Prix du marché aujourd'hui'
 * - Une section 'Mes dernières annonces' avec un appel à getMyHarvests()
 *   affichant le produit, la quantité et le statut de chaque récolte."
 */
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const FarmerDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  return (
    <div style={{ padding: 20 }}>
      <h2>👨‍🌾 Bonjour, {user?.fullName || 'Agriculteur'}</h2>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 15, marginTop: 20 }}>
        <button onClick={() => navigate('/farmer/create')} style={{ padding: 20, fontSize: 16 }}>
          📸 Publier une récolte
        </button>
        <button onClick={() => navigate('/farmer/my-harvests')} style={{ padding: 20, fontSize: 16 }}>
          📦 Mes annonces
        </button>
      </div>
      {/* TODO R : Charger et afficher getMyHarvests() ici */}
    </div>
  );
};
export default FarmerDashboard;
