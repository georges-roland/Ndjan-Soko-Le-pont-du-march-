/**
 * Formulaire de création d'annonce de récolte.
 * RESPONSABLE : R
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * "Crée un formulaire React multi-étapes pour créer une récolte :
 * Étape 1 - Photo : bouton pour prendre/téléverser une photo du produit.
 *   Afficher un encadré simulant l'analyse IA : 'Analyse en cours...' puis
 *   'Catégorie A - Maturité 85%' (données mockées car TFLite est sur mobile).
 *   Appeler suggestPrice() de l'API pour afficher le prix suggéré.
 * Étape 2 - Détails : sélect pour le produit (Tomate/Manioc/Plantain...),
 *   input pour la quantité (kg), input pour le prix (FCFA/kg).
 * Étape 3 - Localisation : bouton 'Utiliser ma position GPS' (navigator.geolocation),
 *   et un input texte pour le nom du village.
 * Étape 4 - Confirmation : résumé + bouton 'Publier'. Appeler createHarvest()."
 */
import React, { useState } from 'react';
import { createHarvest } from '../../api/harvestApi';
import { useNavigate } from 'react-router-dom';

const CreateHarvestPage = () => {
  const [step, setStep] = useState(1);
  const navigate = useNavigate();
  return (
    <div style={{ padding: 20 }}>
      <h2>📸 Publier ma récolte - Étape {step}/4</h2>
      {/* TODO R : Implémenter les 4 étapes avec l'aide de l'IA */}
      <p>🚧 TODO R : Formulaire multi-étapes</p>
    </div>
  );
};
export default CreateHarvestPage;
