/**
 * Page de choix du rôle lors de la première inscription.
 * RESPONSABLE : F
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * "Crée un composant React avec 4 grands boutons visuels (cartes cliquables)
 * pour choisir le rôle : Agriculteur (🌱), Acheteur (🛒), Transporteur (🚚),
 * Gérant Hub (🏪). Au clic, stocker le rôle sélectionné dans un état et
 * afficher un bouton 'Confirmer'. Au clic sur Confirmer, naviguer vers /login
 * avec le rôle en paramètre d'état (useNavigate)."
 */
import React from 'react';
const RegisterRolePage = () => (
  <div style={{ padding: 20 }}>
    <h2>Je suis...</h2>
    {/* TODO F : 4 cartes de choix de rôle */}
    <p>🚧 TODO F : Implémenter la sélection de rôle</p>
  </div>
);
export default RegisterRolePage;
