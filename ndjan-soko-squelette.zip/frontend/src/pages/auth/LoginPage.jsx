/**
 * Page de connexion OTP SMS.
 * RESPONSABLE : F
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * "Crée un composant React LoginPage avec deux étapes :
 * Étape 1 : un formulaire avec un champ input pour le numéro de téléphone
 * (format camerounais 6XXXXXXXX) et un bouton 'Recevoir le code'.
 * Au clic, appeler sendOtp() depuis authApi.js.
 * Étape 2 : afficher 6 cases pour saisir le code OTP (un chiffre par case).
 * Au remplissage complet, appeler verifyOtp() automatiquement.
 * Si la réponse contient un token, appeler login(token) du AuthContext
 * puis rediriger vers '/' (le routeur se charge de la suite selon le rôle)."
 */
import React, { useState } from 'react';
import { sendOtp, verifyOtp } from '../../api/authApi';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const LoginPage = () => {
  const [step, setStep] = useState(1);
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  // TODO F : Implémenter handleSendOtp() et handleVerifyOtp() avec l'aide de l'IA

  return (
    <div style={{ padding: 20, maxWidth: 400, margin: '0 auto' }}>
      <h1>🌿 Ndjan-Soko</h1>
      <h2>Le Pont du Marché</h2>
      {step === 1 ? (
        <div>
          <p>Entrez votre numéro MTN ou Orange :</p>
          <input
            type="tel"
            placeholder="6XXXXXXXX"
            value={phone}
            onChange={e => setPhone(e.target.value)}
            style={{ width: '100%', padding: 10, fontSize: 18 }}
          />
          <button onClick={() => { /* TODO F */ }} style={{ marginTop: 10, width: '100%', padding: 12 }}>
            Recevoir le code SMS
          </button>
        </div>
      ) : (
        <div>
          <p>Entrez le code reçu par SMS :</p>
          <input
            type="text"
            maxLength={6}
            placeholder="123456"
            value={code}
            onChange={e => setCode(e.target.value)}
            style={{ width: '100%', padding: 10, fontSize: 24, letterSpacing: 8 }}
          />
          <button onClick={() => { /* TODO F */ }} style={{ marginTop: 10, width: '100%', padding: 12 }}>
            Se connecter
          </button>
        </div>
      )}
    </div>
  );
};

export default LoginPage;
