package com.ndjansoko.modules.auth.controller;

import com.ndjansoko.modules.auth.dto.*;
import com.ndjansoko.modules.auth.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Contrôleur REST pour l'authentification.
 * RESPONSABLE : F
 *
 * Endpoints :
 *   POST /api/auth/send-otp   -> Envoie le code OTP
 *   POST /api/auth/verify-otp -> Vérifie le code et retourne le JWT
 */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@CrossOrigin(origins = "${cors.allowed-origins}")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/send-otp")
    public ResponseEntity<String> sendOtp(@Valid @RequestBody OtpRequestDto dto) {
        return ResponseEntity.ok(authService.sendOtp(dto));
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<String> verifyOtp(@Valid @RequestBody OtpVerifyDto dto) {
        return ResponseEntity.ok(authService.verifyOtp(dto));
    }
}
