package com.ndjansoko.modules.auth.service;

import com.ndjansoko.modules.auth.dto.*;
import com.ndjansoko.modules.auth.model.*;
import com.ndjansoko.modules.auth.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.Random;

/**
 * Service d'authentification par OTP SMS.
 * RESPONSABLE : F
 *
 * COMMENT COMPLÉTER CE SERVICE AVEC L'IA :
 * Demande à l'IA : "Dans ce service Spring Boot, complète la méthode sendOtp()
 * pour générer un code à 6 chiffres aléatoire, le sauvegarder en base avec une
 * expiration de 10 minutes, et afficher le code dans les logs (simulation SMS).
 * Complète aussi verifyOtp() pour valider le code, créer l'utilisateur s'il
 * n'existe pas, et retourner un JWT signé."
 */
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final OtpRepository otpRepository;
    // private final JwtService jwtService; // TODO F : décommenter après implémentation JwtService

    /**
     * Étape 1 : Génère et envoie (simule) un OTP par SMS.
     * TODO F : Implémenter avec l'aide de l'IA selon le commentaire ci-dessus.
     */
    public String sendOtp(OtpRequestDto dto) {
        // Générer code 6 chiffres
        // Sauvegarder en base (OtpCode avec expiration = now + 10min)
        // En dev : afficher dans les logs System.out.println("OTP pour " + phone + " : " + code)
        // Retourner message "OTP envoyé"
        throw new UnsupportedOperationException("TODO F : Implémenter sendOtp()");
    }

    /**
     * Étape 2 : Vérifie le code OTP et retourne un JWT.
     * TODO F : Implémenter avec l'aide de l'IA selon le commentaire ci-dessus.
     */
    public String verifyOtp(OtpVerifyDto dto) {
        // 1. Trouver l'OTP en base
        // 2. Vérifier non expiré et non utilisé
        // 3. Marquer comme utilisé
        // 4. Créer l'User si première connexion (avec le rôle fourni)
        // 5. Générer et retourner le JWT
        throw new UnsupportedOperationException("TODO F : Implémenter verifyOtp()");
    }
}
