package com.ndjansoko.modules.auth.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

/**
 * DTO pour la demande d'OTP.
 * RESPONSABLE : F
 */
@Data
public class OtpRequestDto {

    @NotBlank(message = "Le numéro de téléphone est obligatoire")
    @Pattern(regexp = "^(237)?[67][0-9]{8}$", message = "Numéro camerounais invalide")
    private String phoneNumber;
}
