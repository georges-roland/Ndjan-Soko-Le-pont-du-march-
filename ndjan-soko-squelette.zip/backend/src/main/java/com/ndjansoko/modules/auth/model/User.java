package com.ndjansoko.modules.auth.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

/**
 * Entité Utilisateur principale.
 * RESPONSABLE : F
 * Représente tous les acteurs : Agriculteur, Acheteur, Transporteur, Hub.
 */
@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String phoneNumber;          // Numéro MTN ou Orange (identifiant unique)

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private UserRole role;               // FARMER, BUYER, TRANSPORTER, HUB_MANAGER

    private String fullName;
    private String city;                 // Ville ou village

    @Column(nullable = false, columnDefinition = "DECIMAL(3,2) DEFAULT 5.00")
    private Double trustScore = 5.0;     // Note de confiance /5

    private Integer totalRatings = 0;

    @Column(nullable = false, columnDefinition = "BOOLEAN DEFAULT TRUE")
    private Boolean isActive = true;     // false si note < 3/5

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    private LocalDateTime lastLogin;

    // ====================================================
    // TODO F : Ajouter ici la logique de calcul de trust score
    // Règle : si trustScore < 3.0, mettre isActive = false
    // ====================================================
}
