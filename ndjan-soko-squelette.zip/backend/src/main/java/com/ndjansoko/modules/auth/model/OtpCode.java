package com.ndjansoko.modules.auth.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * Code OTP SMS temporaire pour l'authentification sans mot de passe.
 * RESPONSABLE : F
 * Durée de vie : 10 minutes. Usage unique.
 */
@Entity
@Table(name = "otp_codes")
@Data
public class OtpCode {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String phoneNumber;

    @Column(nullable = false, length = 6)
    private String code;             // Code à 6 chiffres

    @Column(nullable = false)
    private LocalDateTime expiresAt; // createdAt + 10 minutes

    private Boolean used = false;

    // ====================================================
    // TODO F : Implémenter isValid() -> !used && LocalDateTime.now().isBefore(expiresAt)
    // ====================================================
}
