package com.ndjansoko.modules.auth.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

/**
 * DTO pour la vérification du code OTP.
 * RESPONSABLE : F
 */
@Data
public class OtpVerifyDto {

    @NotBlank
    private String phoneNumber;

    @NotBlank
    @Pattern(regexp = "^[0-9]{6}$", message = "Le code OTP doit être 6 chiffres")
    private String code;

    private String role; // Seulement à la 1ère connexion : "FARMER", "BUYER", etc.
}
