package com.ndjansoko.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Configuration de Spring Security.
 * RESPONSABLE : A
 *
 * COMMENT COMPLÉTER AVEC L'IA :
 * "Dans cette classe Spring Security, configure la chaîne de filtres pour :
 * - Désactiver CSRF (API REST stateless)
 * - Permettre l'accès public à /api/auth/** et /api/ussd et /api/prices/today
 * - Exiger JWT pour tous les autres endpoints
 * - Ajouter un JwtAuthenticationFilter (classe à créer) avant UsernamePasswordAuthenticationFilter
 * Crée aussi la classe JwtService avec les méthodes generateToken(User) et
 * validateToken(String token) en utilisant la bibliothèque io.jsonwebtoken."
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                // Public : auth + USSD + prix du marché
                .requestMatchers("/api/auth/**", "/api/ussd", "/api/prices/today").permitAll()
                // TODO A : Ajouter le filtre JWT pour les routes protégées
                .anyRequest().authenticated()
            );

        // TODO A : Ajouter le JwtAuthenticationFilter ici
        // http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
